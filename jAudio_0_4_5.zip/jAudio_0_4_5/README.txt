==========================================================================
 jAudio 0.4.5
 by Daniel McEnnis and Cory McKay (prior to version 0.4.0)
==========================================================================


-- OVERVIEW -- 

jAudio is an open source Java tool for extracting features from audio
files. It was originally develloped as part of the jMIR music classification 
research software suite, but is now developed independently by Daniel
McEnnis. More information on jMIR is available at http://jmir.sourceforge.net.

The release posted here is simply a copy of the work that Daniel McEnnis
has done independently and posted on the dedicated jAudio SourceForge pages:

http://jaudio.sourceforge.net
http://sourceforge.net/projects/jaudio/

These pages should be checked for more recent versions. Please contact
Daniel McEnnis (<dm75@cs.waikato.ac.nz) with any questions about the
current version of jAudio. Cory McKay (cory.mckay@mail.mcgill.ca) may
also be contacted regarding versions of jAudio earlier than 0.4.0.


-- FAQ --

Although the jAudio software is documented on its dedicated SourceForge
page, there are several recurring questions that are answered below:

1) How do I obtain source code for jAudio?

There are 2 methods. One is to access the CVS repository 
(cvs.sf.net/projects/jaudio) or download the installer, install jAudio, and 
unzip jAudio.jar, which contains the jAudio source code.

2) I am unable to extract features.

Solution 1: You may be running out of memory. The Java JRE does not always 
allocate sufficient memory for jAudio to process large music 
collections. It is therefore sometimes preferable to manually allocate a greater
amount of memory to jAudio before running it. 500 MB should be more
than enough for most situations. This can be done by entering the 
following at the command prompt:

	java -ms16M -mx500M -jar jAudio.jar

Solution 2: You may not have the mp3plugin.jar file properly installed in the Java
extensions directory (e.g. Java/jre1.5.0_02/lib/ext). Copy it there. It may
be downloaded from:

http://java.sun.com/javase/technologies/desktop/media/jmf/mp3/download.html

